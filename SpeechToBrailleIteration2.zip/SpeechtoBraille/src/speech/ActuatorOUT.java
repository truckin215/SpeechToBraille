package speech;

public class ActuatorOUT {

}

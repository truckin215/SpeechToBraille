package speech;
//import for Pi GPIO controller
import com.pi4j.Pi4J;
import com.pi4j.context.Context;
import com.pi4j.io.gpio.digital.*;

public class ActuatorController {
	
}
